import React from 'react';
import { RiArrowLeftSLine, RiCloseCircleLine } from 'react-icons/ri';
import '../style/App.css';

const CharacterModal = ({ character, onClose }) => {
    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button onClick={onClose} className="close-button">
                    <RiArrowLeftSLine />
                </button>
                <button onClick={onClose} className="close-button" style={{ color: 'red', position: 'absolute', right: '10px', top: '10px', background: 'none', border: 'none' }}>
                    <RiCloseCircleLine />
                </button>
                <h2>{character.name}</h2>
                <img src={character.image} alt={character.name} className="character-image" />
                <p><strong>Estado:</strong> {character.status}</p>
            </div>
        </div>
    );
};

export default CharacterModal;
