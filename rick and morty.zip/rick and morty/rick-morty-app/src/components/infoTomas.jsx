import React from 'react';
import { useNavigate } from 'react-router-dom'; 
import imagen3 from '../images/imagen 3.jpeg'; 

const InfoTomas = () => {
  const navigate = useNavigate(); 

  const handleBackButtonClick = () => {
    navigate(-1); 
  };

  return (
    <div className="InfoTomas">
      <div className="info-container">
        <div className="image-container">
          <img src={imagen3} alt="Descripción de la imagen 3" />
        </div>
        <div className="text-container">
          <center><h1>Todo sobre la vida de Tomás Sepúlveda</h1></center>
          <center><p>Aquí sabrás algunos datos compartidos por Tomás.</p></center>
          <h2>Datos personales</h2>
          <p>
            Mi nombre es Tomás Andrés Sepúlveda Jiménez. Tengo 19 años y vivo en la comuna 1, Popular. 
            Resido con mi madre y mi tío. Me gusta mucho el deporte, especialmente el fútbol. 
            Mis colores favoritos son el negro y el rojo. Me gustaría tener un perro San Bernardo y un futuro grandioso.
          </p>
          <h2>Metas profesionales</h2>
          <p>
            Mi meta es llegar a una empresa donde mi presencia muestre un gran cambio y donde mi trabajo se vea reflejado en lo que se espera de mí. 
            Aspiro a contribuir de manera significativa y positiva en el lugar donde me desarrolle profesionalmente.
          </p>
        </div>
      </div>
      <button onClick={handleBackButtonClick} className="back-button">Regresar</button>
    </div>
  );
};

export default InfoTomas;
