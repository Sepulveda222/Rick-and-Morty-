import React, { useEffect, useState } from 'react';
import { getCharacters } from '../services/api';
import CharacterCard from './CharacterCard';
import CharacterModal from './CharacterModal';
import '../style/App.css';
import { useNavigate } from 'react-router-dom';

const CharacterList = () => {
  const [characters, setCharacters] = useState([]);
  const [selectedCharacter, setSelectedCharacter] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const data = await getCharacters();
      setCharacters(data);
    };
    fetchData();
  }, []);

  const handleCharacterClick = (character) => {
    setSelectedCharacter(character);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCharacter(null);
  };

  const handleBackButtonClick = () => {
    navigate('/');
  };

  return (
    <div>
      <div className="character-list">
        {characters.map((character) => (
          <div key={character.id} onClick={() => handleCharacterClick(character)}>
            <CharacterCard character={character} />
          </div>
        ))}
      </div>
      <button onClick={handleBackButtonClick} className="back-button">Regresar</button>
      {isModalOpen && (
        <CharacterModal character={selectedCharacter} onClose={closeModal} />
      )}
    </div>
  );
};

export default CharacterList;
