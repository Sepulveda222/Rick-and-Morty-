import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import CharacterList from './components/CharacterList';
import InfoTomas from './components/infoTomas';
import './style/App.css';
import imagen1 from './images/imagen 1.jpeg';
import imagen2 from './images/imagen 2.jpeg';

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/info-tomas" element={<InfoTomas />} />
          <Route path="/rick-and-morty" element={<CharacterList />} />
        </Routes>
      </div>
    </Router>
  );
};

const Home = () => {
  return (
    <div className="Home">
      <center><h1>Empezar...🚀</h1></center>
      <div className="button-container">
        <Link to="/info-tomas">
          <button className="info-button">Información sobre la vida de Tomás</button>
        </Link>
        <Link to="/rick-and-morty">
          <button class="character-button">Ver personajes de rick and morty</button>
        </Link>
      </div>
      <div className="image-container">
        <img src={imagen1} alt="Descripción de la imagen 1" />
        <img src={imagen2} alt="Descripción de la imagen 2" />
      </div>
    </div>
  );
};

export default App;
