import React from 'react';
import '../style/App.css'; 

const CharacterCard = ({ character }) => {
  const { name, status, image } = character;

  return (
    <div className="character-card">
      <img src={image} alt={name} className="character-image" />
      <h3>{name}</h3>
      <p>Status: {status}</p>
    </div>
  );
};

export default CharacterCard;
