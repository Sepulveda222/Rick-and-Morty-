import React from 'react';
import CharacterList from './components/CharacterList';
import './style/App.css'; 
const App = () => {
  return (
    <div className="App">
      <header className="App-header">
        <center><h1>Caracteres de Rick and Morty</h1></center>
      </header>
      <main>
        <CharacterList />
      </main>
    </div>
  );
};

export default App;
